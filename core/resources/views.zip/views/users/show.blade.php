@extends('layouts.master')

@section('content')
<div style="max-width: 600px; margin: 0 auto; padding: 20px;">
    <a href="{{ route('users.index') }}" style="color: #2563eb; text-decoration: none; display: inline-block; margin-bottom: 20px;">&larr; Back to Users</a>

    <div style="background: #f9fafb; border: 1px solid #e5e7eb; padding: 25px; border-radius: 8px;">
        <h3 style="margin-top: 0;">User Profile Details</h3>
        <hr style="border: 0; border-top: 1px solid #e5e7eb; margin-bottom: 15px;">

        <p><strong>Full Name:</strong> {{ $user->first_name }} {{ $user->last_name }}</p>
        <p><strong>Email:</strong> {{ $user->email }}</p>
        <p><strong>Role:</strong> {{ ucfirst($user->role) }}</p>
        <p><strong>Age:</strong> {{ $user->age ?? 'Not Specified' }}</p>
        <p><strong>Country:</strong> {{ $user->country ?? 'Not Specified' }}</p>
        <p><strong>Joined On:</strong> {{ $user->created_at->format('M d, Y') }}</p>

        <div style="margin-top: 25px; display: flex; gap: 10px;">
            <a href="{{ route('users.edit', $user) }}" style="background: #d97706; color: white; padding: 8px 15px; text-decoration: none; border-radius: 4px;">Edit Profile</a>
            
            <form action="{{ route('users.destroy', $user) }}" method="POST" onsubmit="return confirm('Are you sure you want to completely remove this user account?');">
                @csrf
                @method('DELETE')
                <button type="submit" style="background: #dc2626; color: white; padding: 8px 15px; border: none; border-radius: 4px; cursor: pointer;">Delete Account</button>
            </form>
        </div>
    </div>
</div>
@endsection