@extends('layouts.master')

@section('content')
<div style="max-width: 1100px; margin: 0 auto; padding: 20px;">
    <h2>Registered Users</h2>

    @if(session('success'))
        <div style="background: #d1fae5; color: #065f46; padding: 10px; margin-bottom: 20px; border-radius: 4px;">
            {{ session('success') }}
        </div>
    @endif

    @if(session('error'))
        <div style="background: #fee2e2; color: #991b1b; padding: 10px; margin-bottom: 20px; border-radius: 4px;">
            {{ session('error') }}
        </div>
    @endif

    <table style="width: 100%; border-collapse: collapse; margin-top: 15px;">
        <thead>
            <tr style="background: #f3f4f6; text-align: left;">
                <th style="padding: 12px; border-bottom: 2px solid #e5e7eb;">Name</th>
                <th style="padding: 12px; border-bottom: 2px solid #e5e7eb;">Email</th>
                <th style="padding: 12px; border-bottom: 2px solid #e5e7eb;">Role</th>
                <th style="padding: 12px; border-bottom: 2px solid #e5e7eb;">Country</th>
                <th style="padding: 12px; border-bottom: 2px solid #e5e7eb;">Actions</th>
            </tr>
        </thead>
        <tbody>
            @forelse($users as $user)
                <tr>
                    <td style="padding: 12px; border-bottom: 1px solid #e5e7eb;">{{ $user->first_name }} {{ $user->last_name }}</td>
                    <td style="padding: 12px; border-bottom: 1px solid #e5e7eb;">{{ $user->email }}</td>
                    <td style="padding: 12px; border-bottom: 1px solid #e5e7eb;">
                        <span style="background: #e0f2fe; color: #0369a1; padding: 3px 8px; border-radius: 12px; font-size: 12px;">
                            {{ ucfirst($user->role) }}
                        </span>
                    </td>
                    <td style="padding: 12px; border-bottom: 1px solid #e5e7eb;">{{ $user->country ?? 'N/A' }}</td>
                    <td style="padding: 12px; border-bottom: 1px solid #e5e7eb; display: flex; gap: 12px;">
                        <a href="{{ route('users.show', $user) }}" style="color: #2563eb; text-decoration: none;">Profile</a>
                        <a href="{{ route('users.edit', $user) }}" style="color: #d97706; text-decoration: none;">Edit</a>
                        
                        <form action="{{ route('users.destroy', $user) }}" method="POST" onsubmit="return confirm('Are you sure you want to delete this user?');">
                            @csrf
                            @method('DELETE')
                            <button type="submit" style="background: none; border: none; color: #dc2626; cursor: pointer; padding: 0;">Delete</button>
                        </form>
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="5" style="padding: 20px; text-align: center; color: #6b7280;">No users found.</td>
                </tr>
            @endforelse
        </tbody>
    </table>

    <div style="margin-top: 20px;">
        {{ $users->links() }}
    </div>
</div>
@endsection