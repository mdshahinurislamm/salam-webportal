@extends('layouts.master')

@section('content')
<div style="max-width: 600px; margin: 0 auto; padding: 20px;">
    <h2>Edit Profile: {{ $user->first_name }}</h2>

    @if ($errors->any())
        <div style="background: #fee2e2; color: #991b1b; padding: 10px; margin-bottom: 20px; border-radius: 4px;">
            <ul style="margin: 0; padding-left: 20px;">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('users.update', $user) }}" method="POST">
        @csrf
        @method('PUT')

        <div style="display: flex; gap: 15px; margin-bottom: 15px;">
            <div style="flex: 1;">
                <label style="display: block; margin-bottom: 5px;">First Name</label>
                <input type="text" name="first_name" value="{{ old('first_name', $user->first_name) }}" style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;" required>
            </div>
            <div style="flex: 1;">
                <label style="display: block; margin-bottom: 5px;">Last Name</label>
                <input type="text" name="last_name" value="{{ old('last_name', $user->last_name) }}" style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;" required>
            </div>
        </div>

        <div style="margin-bottom: 15px;">
            <label style="display: block; margin-bottom: 5px;">Email Address</label>
            <input type="email" name="email" value="{{ old('email', $user->email) }}" style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;" required>
        </div>

        <div style="display: flex; gap: 15px; margin-bottom: 15px;">
            <div style="flex: 1;">
                <label style="display: block; margin-bottom: 5px;">Role</label>
                <input type="text" name="role" value="{{ old('role', $user->role) }}" style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;" required>
            </div>
            <div style="flex: 1;">
                <label style="display: block; margin-bottom: 5px;">Age</label>
                <input type="number" name="age" value="{{ old('age', $user->age) }}" style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
            </div>
        </div>

        <div style="margin-bottom: 25px;">
            <label style="display: block; margin-bottom: 5px;">Country</label>
            <input type="text" name="country" value="{{ old('country', $user->country) }}" style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
        </div>

        <hr style="border: 0; border-top: 1px solid #e5e7eb; margin-bottom: 20px;">
        <p style="color: #6b7280; font-size: 14px; margin-bottom: 15px;">Leave fields below blank if you do not wish to change the password.</p>

        <div style="margin-bottom: 15px;">
            <label style="display: block; margin-bottom: 5px;">New Password</label>
            <input type="password" name="password" style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
        </div>

        <div style="margin-bottom: 20px;">
            <label style="display: block; margin-bottom: 5px;">Confirm New Password</label>
            <input type="password" name="password_confirmation" style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
        </div>

        <button type="submit" style="background: #2563eb; color: white; padding: 10px 15px; border: none; border-radius: 4px; cursor: pointer;">Update Profile</button>
        <a href="{{ route('users.index') }}" style="margin-left: 10px; color: #4b5563; text-decoration: none;">Cancel</a>
    </form>
</div>
@endsection