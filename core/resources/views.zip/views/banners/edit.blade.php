@extends('layouts.master')

@section('content')
<div style="max-width: 500px; margin: 0 auto; padding: 20px;">
    <h2>Edit Banner</h2>

    <form action="{{ route('banners.update', $banner) }}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PUT')

        <div style="margin-bottom: 15px;">
            <label style="display: block; margin-bottom: 5px;">Banner Name</label>
            <input type="text" name="name" value="{{ old('name', $banner->name) }}" style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;" required>
        </div>

        <div style="margin-bottom: 20px;">
            <label style="display: block; margin-bottom: 5px;">Change Image (Optional)</label>
            <div style="margin-bottom: 10px;">
                <img src="{{ asset('storage/' . $banner->image) }}" alt="Current Banner" style="width: 150px; border-radius: 4px;">
            </div>
            <input type="file" name="image" style="width: 100%;">
        </div>

        <button type="submit" style="background: #d97706; color: white; padding: 10px 15px; border: none; border-radius: 4px; cursor: pointer;">Update Banner</button>
        <a href="{{ route('banners.index') }}" style="margin-left: 10px; color: #4b5563; text-decoration: none;">Cancel</a>
    </form>
</div>
@endsection