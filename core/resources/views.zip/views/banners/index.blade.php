@extends('layouts.master')

@section('content')
<div style="max-width: 900px; margin: 0 auto; padding: 20px;">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <h2>Banners</h2>
        <a href="{{ route('banners.create') }}" style="background: #2563eb; color: white; padding: 8px 12px; text-decoration: none; border-radius: 4px;">Add Banner</a>
    </div>

    @if(session('success'))
        <div style="background: #d1fae5; color: #065f46; padding: 10px; margin-bottom: 20px; border-radius: 4px;">
            {{ session('success') }}
        </div>
    @endif

    <table style="width: 100%; border-collapse: collapse;">
        <thead>
            <tr style="background: #f3f4f6; text-align: left;">
                <th style="padding: 10px; border-bottom: 2px solid #e5e7eb;">Preview</th>
                <th style="padding: 10px; border-bottom: 2px solid #e5e7eb;">Name</th>
                <th style="padding: 10px; border-bottom: 2px solid #e5e7eb;">Actions</th>
            </tr>
        </thead>
        <tbody>
            @forelse($banners as $banner)
                <tr>
                    <td style="padding: 10px; border-bottom: 1px solid #e5e7eb;">
                        <img src="{{ asset('storage/' . $banner->image) }}" alt="{{ $banner->name }}" style="width: 100px; height: auto; border-radius: 4px;">
                    </td>
                    <td style="padding: 10px; border-bottom: 1px solid #e5e7eb;"><strong>{{ $banner->name }}</strong></td>
                    <td style="padding: 10px; border-bottom: 1px solid #e5e7eb; display: flex; gap: 10px; align-items: center;">
                        <a href="{{ route('banners.edit', $banner) }}" style="color: #d97706; text-decoration: none;">Edit</a>
                        <form action="{{ route('banners.destroy', $banner) }}" method="POST" onsubmit="return confirm('Delete this banner?');">
                            @csrf
                            @method('DELETE')
                            <button type="submit" style="background: none; border: none; color: #dc2626; cursor: pointer; padding: 0;">Delete</button>
                        </form>
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="3" style="padding: 20px; text-align: center; color: #6b7280;">No banners found.</td>
                </tr>
            @endforelse
        </tbody>
    </table>

    <div style="margin-top: 20px;">
        {{ $banners->links() }}
    </div>
</div>
@endsection