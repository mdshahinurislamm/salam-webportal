@extends('layouts.master')

@section('content')
<div style="max-width: 500px; margin: 0 auto; padding: 20px;">
    <h2>Create Banner</h2>

    <form action="{{ route('banners.store') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <div style="margin-bottom: 15px;">
            <label style="display: block; margin-bottom: 5px;">Banner Name</label>
            <input type="text" name="name" value="{{ old('name') }}" style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;" required>
        </div>

        <div style="margin-bottom: 20px;">
            <label style="display: block; margin-bottom: 5px;">Upload Image</label>
            <input type="file" name="image" style="width: 100%;" required>
        </div>

        <button type="submit" style="background: #2563eb; color: white; padding: 10px 15px; border: none; border-radius: 4px; cursor: pointer;">Save Banner</button>
        <a href="{{ route('banners.index') }}" style="margin-left: 10px; color: #4b5563; text-decoration: none;">Cancel</a>
    </form>
</div>
@endsection