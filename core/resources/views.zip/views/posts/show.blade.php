@extends('layouts.master')

@section('content')
<div class="container" style="max-width: 800px; margin: 0 auto; padding: 20px;">
    <a href="{{ route('posts.index') }}" style="color: #2563eb; text-decoration: none; display: inline-block; margin-bottom: 20px;">&larr; Back to Posts</a>

    <article>
        <h1 style="margin-bottom: 10px;">{{ $post->title }}</h1>
        
        <div style="color: #6b7280; font-size: 14px; margin-bottom: 20px;">
            <span>Published by: <strong>{{ $post->user->first_name ?? 'Unknown' }}</strong></span> | 
            <span>Date: {{ $post->created_at->format('M d, Y') }}</span> 
            @if($post->type)
                | <span>Category: {{ $post->type }}</span>
            @endif
        </div>

        @if($post->image)
            <div style="margin-bottom: 20px; display: flex; gap: 10px;">
                <a href="{{ asset('storage/' . $post->image) }}" target="_blank" style="background: #10b981; color: white; padding: 10px 15px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-flex; align-items: center; gap: 5px;">
                    📄 Open / View PDF
                </a>
                <a href="{{ asset('storage/' . $post->image) }}" download style="background: #4b5563; color: white; padding: 10px 15px; text-decoration: none; border-radius: 5px; font-weight: bold;">
                    📥 Download PDF
                </a>
            </div>

            <div style="margin-bottom: 20px;">
                <embed src="{{ asset('storage/' . $post->image) }}" type="application/pdf" width="100%" height="500px" style="border: 1px solid #e5e7eb; border-radius: 8px;" />
            </div>
        @endif

        <div style="line-height: 1.6; font-size: 16px; color: #1f2937; white-space: pre-line;">
            {{ $post->languages }}
        </div>
    </article>

    <div style="margin-top: 40px; border-top: 1px solid #e5e7eb; padding-top: 20px; display: flex; gap: 10px;">
        <a href="{{ route('posts.edit', $post) }}" style="background: #d97706; color: white; padding: 8px 15px; text-decoration: none; border-radius: 5px;">Edit Post</a>
        
        <form action="{{ route('posts.destroy', $post) }}" method="POST" onsubmit="return confirm('Are you sure you want to delete this post?');">
            @csrf
            @method('DELETE')
            <button type="submit" style="background: #dc2626; color: white; padding: 8px 15px; border: none; border-radius: 5px; cursor: pointer;">Delete Post</button>
        </form>
    </div>
</div>
@endsection