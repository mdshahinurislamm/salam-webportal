@extends('layouts.master')

@section('content')
<div class="container" style="max-width: 600px; margin: 0 auto; padding: 20px;">
    <h2>Create Post</h2>

    @if ($errors->any())
        <div style="background: #fee2e2; color: #991b1b; padding: 10px; margin-bottom: 20px; border-radius: 5px;">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('posts.store') }}" method="POST" enctype="multipart/form-data">
        @csrf

        <div style="margin-bottom: 15px;">
            <label style="display: block; margin-bottom: 5px;">Title</label>
            <input type="text" name="title" value="{{ old('title') }}" style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;" required>
        </div>

        <div style="margin-bottom: 15px;">
            <label style="display: block; margin-bottom: 5px;">Age Group</label>
            <select class="form-select" name="type"> 
                <option value="group_a">Group A</option>
                <option value="group_b">Group B</option>
            </select> 
        </div>

        <div style="margin-bottom: 15px;">
            <label style="display: block; margin-bottom: 5px;">languages</label>

            <select class="form-select" name="languages"> 
                <option value="english">English</option>
                <option value="arabic">Arabic</option>
            </select> 
            
        </div>

        <div style="margin-bottom: 15px;">
            <label style="display: block; margin-bottom: 5px;">PDFs</label>
            <input type="file" name="image" accept="application/pdf" style="width: 100%;">
        </div>

        <div style="margin-bottom: 20px;">
            <label>
                <input type="checkbox" name="is_published" value="1" {{ old('is_published') ? 'checked' : '' }}> Publish Immediately
            </label>
        </div>

        <button type="submit" style="background: #2563eb; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer;">Save Post</button>
        <a href="{{ route('posts.index') }}" style="margin-left: 10px; color: #4b5563; text-decoration: none;">Cancel</a>
    </form>
</div>
@endsection