@extends('layouts.master')

@section('content')
<div class="container" style="max-width: 1000px; margin: 0 auto; padding: 20px;">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <h2>All PDFs</h2>
        <a href="{{ route('posts.create') }}" style="background: #2563eb; color: white; padding: 10px 15px; text-decoration: none; border-radius: 5px;">Create New Post</a>
    </div>

    @if(session('success'))
        <div style="background: #d1fae5; color: #065f46; padding: 10px; margin-bottom: 20px; border-radius: 5px;">
            {{ session('success') }}
        </div>
    @endif

    <table style="width: 100%; border-collapse: collapse; margin-top: 10px;">
        <thead>
            <tr style="background: #f3f4f6; text-align: left;">
                <th style="padding: 12px; border-bottom: 2px solid #e5e7eb;">Title</th>
                <th style="padding: 12px; border-bottom: 2px solid #e5e7eb;">Type</th>
                <th style="padding: 12px; border-bottom: 2px solid #e5e7eb;">Status</th>
                <th style="padding: 12px; border-bottom: 2px solid #e5e7eb;">Actions</th>
            </tr>
        </thead>
        <tbody> 
            
            @forelse($posts as $post)
                <tr>
                    <td style="padding: 12px; border-bottom: 1px solid #e5e7eb;">
                        <strong>{{ $post->title }}</strong> <br>
                        <small style="color: #6b7280;">By: {{ $post->user->first_name ?? 'Unknown' }}</small>
                    </td>
                    <td style="padding: 12px; border-bottom: 1px solid #e5e7eb;">{{ $post->type ?? 'N/A' }}</td>
                    <td style="padding: 12px; border-bottom: 1px solid #e5e7eb;">
                        <span style="padding: 3px 8px; border-radius: 12px; font-size: 12px; background: {{ $post->is_published ? '#d1fae5; color: #065f46;' : '#fee2e2; color: #991b1b;' }}">
                            {{ $post->is_published ? 'Published' : 'Draft' }}
                        </span>
                    </td>
                    <td style="padding: 12px; border-bottom: 1px solid #e5e7eb; display: flex; gap: 10px;">
                        <a href="{{ route('posts.show', $post) }}" style="color: #2563eb; text-decoration: none;">View</a>
                        <a href="{{ route('posts.edit', $post) }}" style="color: #d97706; text-decoration: none;">Edit</a>
                        
                        <form action="{{ route('posts.destroy', $post) }}" method="POST" onsubmit="return confirm('Are you sure you want to delete this post?');">
                            @csrf
                            @method('DELETE')
                            <button type="submit" style="background: none; border: none; color: #dc2626; cursor: pointer; padding: 0;">Delete</button>
                        </form>
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="4" style="padding: 12px; text-align: center; color: #6b7280;">No posts found.</td>
                </tr>
            @endforelse
        </tbody>
    </table>

    <div style="margin-top: 20px;">
        {{ $posts->links() }}
    </div>
</div>
@endsection