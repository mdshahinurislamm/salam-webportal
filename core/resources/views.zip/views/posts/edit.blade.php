@extends('layouts.master')

@section('content')
<div class="container" style="max-width: 600px; margin: 0 auto; padding: 20px;">
    <h2>Edit Post</h2>

    @if ($errors->any())
        <div style="background: #fee2e2; color: #991b1b; padding: 10px; margin-bottom: 20px; border-radius: 5px;">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('posts.update', $post) }}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PUT')

        <div style="margin-bottom: 15px;">
            <label style="display: block; margin-bottom: 5px;">Title</label>
            <input type="text" name="title" value="{{ old('title', $post->title) }}" style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;" required>
        </div>

        <div style="margin-bottom: 15px;">
            <label style="display: block; margin-bottom: 5px;">Type</label>
            <select class="form-select" name="type"> 
                <option value="group_a" {{ $post->type == 'group_a' ? 'selected':'' }}>Group A</option>
                <option value="group_b" {{ $post->type == 'group_b' ? 'selected':'' }}>Group B</option>
            </select> 
             
        </div>

        <div style="margin-bottom: 15px;">
            <label style="display: block; margin-bottom: 5px;">Languages</label>

            <select class="form-select" name="languages"> 
                <option value="english" {{ $post->languages == 'english' ? 'selected':'' }}>English</option>
                <option value="arabic" {{ $post->languages == 'arabic' ? 'selected':'' }}>Arabic</option>
            </select> 
 
        </div>

        <div style="margin-bottom: 15px;">
            <label style="display: block; margin-bottom: 5px;">PDF Document</label>
            @if($post->image)
                <div style="margin-bottom: 10px; background: #f3f4f6; padding: 10px; border-radius: 4px;">
                    <a href="{{ asset('storage/' . $post->image) }}" target="_blank" style="color: #2563eb; text-decoration: none; font-weight: bold;">
                        📄 View Current PDF
                    </a>
                </div>
            @endif
            <input type="file" name="image" accept="application/pdf" style="width: 100%;">
        </div>

        <div style="margin-bottom: 20px;">
            <label>
                <input type="checkbox" name="is_published" value="1" {{ old('is_published', $post->is_published) ? 'checked' : '' }}> Published
            </label>
        </div>

        <button type="submit" style="background: #d97706; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer;">Update Post</button>
        <a href="{{ route('posts.index') }}" style="margin-left: 10px; color: #4b5563; text-decoration: none;">Cancel</a>
    </form>
</div>
@endsection